function mySetFontSize(objs,fs)

for i=1:length(objs)
    
   set(objs(i),'FontSize',fs) 
end

end